#!/bin/bash
## Following is an example of the expected command-line arguments.
#mf-compare.sh version_lower.txt version_upper.txt basename version_lower# version_upper#

cd "in"
paste ${1} ${2}						> ../tmp/mf-bw.txt
cd "../tmp"
awk '{printf("%.4f\n",$2-$1)}' mf-bw.txt	> mf-bw-diff.txt 
paste mf-bw.txt mf-bw-diff.txt	> ${3}
cd ".."
rm "tmp/*"
